

public interface IMagic {
	void print();
	void make();
//	void sumOfRandomLine();
}
