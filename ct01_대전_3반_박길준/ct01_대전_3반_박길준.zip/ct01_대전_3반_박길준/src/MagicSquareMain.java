
public class MagicSquareMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 3마방진
		MagicSquare odd = new OddMagicSquare();
		odd.make();
		odd.print();
		odd.totOfMagicsquare();
		odd.sumOfRandomLine();
		
		System.out.println();
		
		// 4마방진
		MagicSquare four = new FourMagicSquare();
		four.make();
		four.print();
		four.totOfMagicsquare();
		four.sumOfRandomLine();
	}

}
