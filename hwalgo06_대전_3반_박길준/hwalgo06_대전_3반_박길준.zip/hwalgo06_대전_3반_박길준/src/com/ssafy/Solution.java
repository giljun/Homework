package com.ssafy;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Solution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		Queue<Integer> cryptogram = new LinkedList<Integer>();
		
		int T = 10;
		
		for (int i = 0; i < T; i++) {
			int case_num = sc.nextInt();
			
			// 8개의 숫자를 queue에 입력받는다.
			for (int j = 0; j < 8; j++) { 
				cryptogram.offer(sc.nextInt());
			}
			
			// queue에서 뺄 때마다, 1씩 증가하는 변수.
			int cnt = 1;
			// queue에서 뺄 때, 받아줄 임시변수.
			int receive_num = 0;
			
			while(true) {
				// 1. queue에서 맨 앞의 원소를 꺼내서 임시변수에 저장한다.
				// 2. 맨 앞의 원소값 - cnt
				// 3. 결과값이 0이 되지는 않았는지 검사.
				// 3.1. 결과값이 0보다 작으면,결과값을 0으로 수정한 뒤, 큐의 맨 마지막으로 보내준다.  
				receive_num = cryptogram.poll();
				receive_num = receive_num - cnt;
				
				// 4. 결과값이 0이하로 나오면, 암호 생성 완료.
				// 5. 마지막 queue에 받은 값을 0으로 바꿔서 넣어주고 종료.
				if( receive_num <= 0 ) {
					receive_num = 0;
					cryptogram.offer(receive_num);
					break;
				} else { // 아니라면, 값을 증가시켜서 반복문 수행.(1싸이클)
					cryptogram.offer(receive_num);
					cnt++; // 1싸이클은 cnt가 5까지만...?
					if(cnt == 6) {
						cnt = 1;
					}
				}
			}
			
			System.out.print("#"+case_num);
			for (int j = 0; j < 8; j++) {
				System.out.print(" "+cryptogram.poll());
			}
			System.out.println();
		}
	}
}
