CREATE TABLE `allergy_tb` (
  `NUM` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(30) NOT NULL,
  `INGREDIENT` varchar(30) NOT NULL,
  PRIMARY KEY (`NUM`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

CREATE TABLE `board_tb` (
  `seq` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `content` text NOT NULL,
  `writer` varchar(45) NOT NULL,
  `wdate` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

CREATE TABLE `food_tb` (
  `seq` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `maker` varchar(45) DEFAULT NULL,
  `material` text,
  `wt` varchar(45) DEFAULT NULL,
  `cal` varchar(45) DEFAULT NULL,
  `car` varchar(45) DEFAULT NULL,
  `pro` varchar(45) DEFAULT NULL,
  `fat` varchar(45) DEFAULT NULL,
  `sugar` varchar(45) DEFAULT NULL,
  `nat` varchar(45) DEFAULT NULL,
  `col` varchar(45) DEFAULT NULL,
  `poh` varchar(45) DEFAULT NULL,
  `tran` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `member_allergy_tb` (
  `ID` varchar(45) NOT NULL,
  `NUM` int(11) NOT NULL,
  PRIMARY KEY (`ID`,`NUM`),
  KEY `NUM` (`NUM`),
  CONSTRAINT `member_allergy_tb_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `member_tb` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `member_allergy_tb_ibfk_2` FOREIGN KEY (`NUM`) REFERENCES `allergy_tb` (`NUM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `member_tb` (
  `NUM` int(11) NOT NULL AUTO_INCREMENT,
  `ID` varchar(30) NOT NULL,
  `NAME` varchar(30) NOT NULL,
  `PW` char(64) NOT NULL,
  `EMAIL` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`NUM`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/* auto increment로 구현하여 글번호는 자동으로 올라갑니다. */
INSERT INTO board_TB(title,content,writer,wdate) values ('게시글1','내용1','작성자1', sysdate());
INSERT INTO board_TB(title,content,writer,wdate) values ('게시글2','내용2','작성자2', sysdate());
INSERT INTO board_TB(title,content,writer,wdate) values ('게시글3','내용3','작성자3', sysdate());
INSERT INTO board_TB(title,content,writer,wdate) values ('게시글4','내용4','작성자4', sysdate());
INSERT INTO board_TB(title,content,writer,wdate) values ('게시글5','내용5','작성자5', sysdate());
INSERT INTO board_TB(title,content,writer,wdate) values ('게시글6','내용6','작성자6', sysdate());
INSERT INTO board_TB(title,content,writer,wdate) values ('게시글7','내용7','작성자7', sysdate());
INSERT INTO board_TB(title,content,writer,wdate) values ('게시글8','내용8','작성자8', sysdate());
INSERT INTO board_TB(title,content,writer,wdate) values ('게시글9','내용9','작성자9', sysdate());
INSERT INTO board_TB(title,content,writer,wdate) values ('게시글10','내용10','작성자10', sysdate());
INSERT INTO board_TB(title,content,writer,wdate) values ('게시글11','내용11','작성자11', sysdate());
