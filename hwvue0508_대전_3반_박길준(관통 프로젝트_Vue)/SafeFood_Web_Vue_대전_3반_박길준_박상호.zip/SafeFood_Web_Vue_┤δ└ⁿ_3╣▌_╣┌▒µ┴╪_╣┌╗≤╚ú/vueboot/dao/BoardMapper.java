package com.ssafy.edu.vue.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.edu.vue.dto.BoardDto;


public interface BoardMapper {
	public List<BoardDto> findAllBoards() throws Exception;
	public void writeBoard(BoardDto boarddto) throws Exception;
	
	public BoardDto findBoardBySeq(int seq) throws Exception;
	
	public boolean updateBoard(BoardDto boarddto) throws Exception;
	public boolean deleteBoard(int seq) throws Exception;
	public BoardDto detailBoard(int seq) throws Exception;
	
	public int findAfterAdd() throws Exception;
}
