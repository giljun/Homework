package com.ssafy.edu.vue.controller;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.edu.vue.dto.BoardDto;
import com.ssafy.edu.vue.help.BoolResult;
import com.ssafy.edu.vue.help.NumberResult;
import com.ssafy.edu.vue.service.IBoardService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;


@CrossOrigin(origins = {"*"}, maxAge = 6000)
@RestController
@RequestMapping("/api")
@Api(value="SSAFY", description="Board Resouces Management 2019")
public class BoardController {

	private static final Logger logger = 
			LoggerFactory.getLogger(BoardController.class);
	
	@Autowired
	private IBoardService iBoardService;
	
	@ApiOperation(value = "모든 게시글의 정보를 반환한다.", response = List.class)
	@RequestMapping(value = "/findAllBoards", method = RequestMethod.GET)
	public ResponseEntity<List<BoardDto>> findAllBoards() throws Exception {
		logger.info("1-------------findAllBoards-----------------------------"+ new Date());
		
		List<BoardDto> boards = iBoardService.findAllBoards();
		
		logger.info("1-------------after findAllBoards-----------------------------"+ boards.toString());
		
		if(boards.isEmpty()) {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<BoardDto>>(boards, HttpStatus.OK);
	}
	
	@ApiOperation(value = "새로운 게시글을 추가한다.", response = NumberResult.class)
	@RequestMapping(value = "/writeBoard", method = RequestMethod.POST)
	public ResponseEntity<NumberResult> writeBoard(@RequestBody BoardDto boarddto) throws Exception {
		logger.info("2-------------writeBoard-----------------------------"+new Date());
   		logger.info("2-------------writeBoard-----------------------------"+ boarddto);
   		int total = iBoardService.writeBoard(boarddto);
   		NumberResult nr=new NumberResult();
   		nr.setCount(total);
   		nr.setName("writeBoard");
   		nr.setState("succ");
   		logger.info("2-------------addEmployee-------id------------------"+total);
   		if (total<=0) {
   			nr.setCount(-1);
   	   		nr.setName("writeBoard");
   	   		nr.setState("fail");
   			return new ResponseEntity<NumberResult>(nr, HttpStatus.OK);
   		}
   		return new ResponseEntity<NumberResult>(nr, HttpStatus.OK);
	}
	
	@ApiOperation(value = "게시된 글의 상세보기를 보여준다.", response = BoardDto.class)
	@RequestMapping(value = "/findBoardBySeq/{seq}", method = RequestMethod.GET)
	public ResponseEntity<BoardDto> findBoardBySeq(@PathVariable int seq) throws Exception {
		logger.info("3-------------findBoardBySeq-----------------------------"+ new Date());
		
		BoardDto board = iBoardService.findBoardBySeq(seq);
		
		logger.info("3-------------after findBoardBySeq-----------------------------"+ board.toString());
		
		if (board==null || board.getSeq()==0) {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<BoardDto>(board, HttpStatus.OK);
	}
	
	@ApiOperation(value = "게시글을 삭제한다.", response = BoolResult.class)
	@RequestMapping(value = "/deleteBoard/{seq}", method = RequestMethod.GET)
	public ResponseEntity<BoolResult> deleteBoard(@PathVariable int seq) throws Exception {
		logger.info("4-------------deleteBoard-----------------------------"+new Date());
   		logger.info("4-------------deleteBoard-----------------------------"+ seq);
   		boolean total = iBoardService.deleteBoard(seq);
   		BoolResult nr=new BoolResult();
   		nr.setCount(total);
   		nr.setName("deleteBoard");
   		nr.setState("succ");
   		if (!total) {
   			return new ResponseEntity(HttpStatus.NO_CONTENT);
   		}
   		return new ResponseEntity<BoolResult>(nr, HttpStatus.OK);
	}
	
	@ApiOperation(value = "게시글을 수정한다.", response = BoolResult.class)
   	@RequestMapping(value = "/updateBoard", method = RequestMethod.POST)
   	public ResponseEntity<BoolResult> updateEmployee(@RequestBody BoardDto boarddto) throws Exception {
   		logger.info("5-------------updateBoard-----------------------------"+new Date());
   		logger.info("5-------------updateBoard-----------------------------"+boarddto);
   		boolean total = iBoardService.updateBoard(boarddto);
   		BoolResult nr=new BoolResult();
   		nr.setCount(total);
   		nr.setName("updateBoard");
   		nr.setState("succ");
   		if (!total) {
   			return new ResponseEntity(HttpStatus.NO_CONTENT);
   		}
   		return new ResponseEntity<BoolResult>(nr, HttpStatus.OK);
   	}
}

